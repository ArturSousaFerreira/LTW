<?php
$types = array('Party', 'Concert', 'Conference', 'Sports', 'Other');
echo json_encode($types);
?>
