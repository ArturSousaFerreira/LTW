<?php
session_start();

include_once("connection.php");

include_once("templates/header.php");
include_once("templates/footer_contact.php");
?>
