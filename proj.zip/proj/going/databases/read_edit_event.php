<?php
session_start();

include_once("events.php");

include_once("templates/header.php");


$logged = isset($_SESSION['username']);

$id = $_GET['id'];
$event = getEvent($id);
$registered = getRegistered($id);
$comments = getComments($id);

?>

<header>

    <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
    <script type="text/javascript" src="../javascript/createEventForm.js"></script>
	
<div id="footer_detail_event">

    <h2>Event info</h2>
    <ul>
        <form action="action_edit_event.php" method="post" enctype="multipart/form-data">

            <select name="type" id="type"></select>
            <br>
            <input type="datetime" name="date" id="date" placeholder="<?= $event['date'] ?>">
            <br>
            <input type="textarea" name="description" placeholder="<?= $event['description'] ?>">
            <br>
            <input type="file" name="image" id="image" placeholder="<?= $event['image'] ?>">
            <br>
            <input type="submit" value="Save" onclick="return createEventForm(this.form);">
            <input type="submit" name="back_btn" value="Back">
        </form>
</div>
</div>
</header>
</body>
</html>


