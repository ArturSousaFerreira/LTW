<?php
$types = array('Party', 'Music', 'Conference', 'Sports', 'Travel', 'Other');
echo json_encode($types);
?>