<?php
$types = array('General party', 'Music', 'Conference', 'Sports', 'Travel', 'Other');
echo json_encode($types);
?>