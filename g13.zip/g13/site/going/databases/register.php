<?php
//session_start();

//include_once("connection.php");

include_once("templates/nav.php");
include_once("templates/header_register.php");
